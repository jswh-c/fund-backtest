# 📈 智能基金定投策略回测与AI优化系统

**Fund DCA Backtest & AI Optimization System**

一个基于 Python 的基金定投策略回测框架，支持 9 种定投策略、机器学习预测、贝叶斯参数优化、交互式可视化和 PDF 报告导出。

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)](https://python.org)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.45-red)](https://streamlit.io)
[![Plotly](https://img.shields.io/badge/Plotly-5.24-green)](https://plotly.com)
[![Tests](https://img.shields.io/badge/Tests-57%20passed-brightgreen)](tests/)
[![License](https://img.shields.io/badge/License-MIT-lightgrey)]()

---

## 🚀 快速开始

### 安装

```bash
git clone https://github.com/YOUR_USERNAME/fund-backtest.git
cd fund_backtest
pip install -r requirements.txt
```

### 运行 Web 界面（推荐）

```bash
streamlit run app.py
```

浏览器自动打开 → 选择基金 → 勾选策略 → 点击 **"运行回测"**

### 命令行模式

```bash
# 单基金全策略回测
python main.py --code 161725 --start 2021-01-01 --all --output

# 批量回测（5只基金 × 8策略）
python backtest.py batch 161725 110011 000001 002610 001632

# 搜索基金代码
python main.py --search 白酒
```

### 运行测试

```bash
pytest tests/ -v
# 57 passed in 0.94s
```

---

## 📁 项目结构

```
fund_backtest/
├── app.py                 # Streamlit Web 主界面 (1100行)
├── backtest.py            # 回测引擎 (8策略 + Optuna优化)
├── strategies.py          # 机器学习策略 (随机森林)
├── data_fetcher.py        # 数据获取 + 缓存 + 异步下载
├── visualization.py       # Plotly 交互式图表
├── pdf_report.py          # PDF 报告生成 (reportlab)
├── utils.py               # 公共工具模块
├── main.py                # CLI 命令行入口
├── write_report.py        # Markdown 报告生成
├── tests/
│   ├── conftest.py        # pytest fixtures
│   └── test_backtest.py   # 57 个单元测试
├── data/                  # 净值数据缓存 (.csv)
├── output/                # 图表/报告输出 (.html, .pdf)
├── .streamlit/
│   └── config.toml        # Streamlit Cloud 部署配置
├── requirements.txt       # 13 个依赖 (精确版本)
├── .gitignore
├── DEPLOY.md              # Streamlit Cloud 部署指南
├── PROJECT_REPORT.md      # 项目详细报告 (6000字)
└── README.md              # 本文件
```

---

## 🎯 策略列表

| # | 策略 | 类型 | 描述 |
|---|------|------|------|
| 1 | **普通定投** | 基准 | 每月固定日期买入固定金额 |
| 2 | **止盈定投** | 止盈 | 收益率达阈值时全部赎回，重新开始 |
| 3 | **价值平均** | 动态 | 每月调整投入使市值按固定目标增长 |
| 4 | **MA250动态** | 均线 | 价格 < MA×0.9 → 2x；> MA×1.1 → 0.5x |
| 5 | **60日均线** | 均线 | 中期趋势判断，±5%偏离度 |
| 6 | **MACD** | 技术指标 | 柱状图强度决定投资倍数 |
| 7 | **RSI** | 技术指标 | 超买超卖信号（30/70阈值） |
| 8 | **波动率** | 技术指标 | 恐慌加仓，平静减仓 |
| 9 | **ML随机森林** | 机器学习 | 16维特征预测涨跌概率，动态调仓 |

## 📊 功能特性

### 回测引擎
- ⚡ **Pandas 全向量化**：8 策略仅需 0.063s（63x 加速）
- 📈 14 项核心指标：年化收益、夏普比率、最大回撤、波动率、胜率、最大连续亏损月数等
- 🔍 **Optuna 贝叶斯优化**：自动搜索最优参数 + 训练/测试分离 + 过拟合检测
- 🤖 **机器学习集成**：随机森林预测市场方向，特征重要性分析

### Web 界面
- 🌙 黑暗模式切换
- ⏳ 实时进度条 + 策略执行状态
- 📑 6 个标签页（对比/收益/回撤/月度/雷达/交易）
- 🔧 实用工具：数据更新、定投计算器、风险预警、快照保存
- 📄 一键生成 PDF 报告（含图表）
- 🏗️ Streamlit Community Cloud 一键部署

### 数据层
- 💾 智能缓存：自动检测过期，>5天未更新自动刷新
- ⚡ 异步批量下载：aiohttp 并发拉取（5并发）
- 🔄 自动复权净值计算（处理分红拆分）
- 🛡️ 3次重试 + 网络失败回退缓存

### 工程质量
- ✅ 57 个 pytest 单元测试
- 📝 完整类型注解 + docstring
- 🎨 Black 格式化 (PEP8)
- 📦 utils.py 公共模块（12个复用函数）

---

## 📈 性能基准

| 指标 | 优化前 | 优化后 | 加速比 |
|------|--------|--------|--------|
| 8策略总耗时 | ~4.0s | 0.063s | **~63x** |
| 单策略平均 | ~500ms | 7.2ms | **~70x** |
| 10轮8策略 | ~40s | 0.576s | **~69x** |

---

## 🔗 常用命令

```bash
# Web 界面
streamlit run app.py

# CLI 单基金
python main.py --code 161725 --start 2021-01-01 --all --output --optimize

# 批量回测
python backtest.py batch 161725 110011 000001

# 测试
pytest tests/ -v

# 代码格式化
black --line-length 100 *.py tests/*.py

# 部署到 Streamlit Cloud
# 详见 DEPLOY.md
```

---

## 📦 依赖

| 包 | 版本 | 用途 |
|----|------|------|
| pandas | 2.2.3 | 数据处理 |
| numpy | 2.1.3 | 数值计算 |
| streamlit | 1.45.1 | Web 界面 |
| plotly | 5.24.1 | 交互式图表 |
| matplotlib | 3.10.0 | PDF 图表渲染 |
| scikit-learn | 1.6.1 | 机器学习策略 |
| optuna | 4.9.0 | 贝叶斯优化 |
| reportlab | 4.5.1 | PDF 报告生成 |
| requests | 2.32.3 | HTTP 请求 |
| aiohttp | 3.11.10 | 异步数据下载 |
| openpyxl | 3.1.5 | Excel 导出 |
| kaleido | 0.2.1 | Plotly 静态导出 |
| nest-asyncio | 1.6.0 | 异步兼容 |

---

## ⚠️ 免责声明

本系统基金净值数据来源于天天基金网（eastmoney.com）公开 API，仅供学习研究使用，**不构成投资建议**。历史回测结果不代表未来表现。投资有风险，入市需谨慎。

---

## 📄 许可证

MIT License
